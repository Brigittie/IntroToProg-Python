#--------------------------------#
#Title: ToDoScript.py
#Dev: Brigittie Tijerina
#Description: This program shows users what chores/priorities have been assigned items in a text file.
# When running the program, users are able to choose add, delete, and print out their new task list onto the text file.
#Change Log: 2019-02-11, Created File
#--------------------------------#

#Reading from the Text file
todo_file = open('C:\TIJERB\\UW_Python\Module05\\todo.txt','r')

#-- Processing --#
# step 1
# when the program starts, load any data you have in a text file called ToDo.txt into a python Dictionary.

# initializing empty dictionary
dict_todo = {}

# for each line in the "todo.txt" file
for line in todo_file:
    # split the line using the comma as a delimiter
    chore_priority_split = line.split(",")
    # take the 0th index, assign to chore
    chore = chore_priority_split[0]
    # take the 1st index, assign to priority
    priority = chore_priority_split[1]
    # count the length of variable priority, and subtract by 1
    # otherwise this will include \n character
    remove_newline_char = len(priority)-1
    # assign new value without \n character back to priority
    priority = priority[0:remove_newline_char]
    # add key/value pair to dictionary
    dict_todo[chore] = priority


# step 2 - Display a menu of choices to the user
while(True):
    print (
    """
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()

    # step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Printing task list and priority value: ")
        # for key values in dictionary
        for keys in dict_todo:
            # get the value of keys, assign to "value"
            value = dict_todo.get(keys)
            # display key and value to user in CX friendly way
            print(keys,"-",value)


    # step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        new_task = input("Input the new task: ")
        # if the user defined task is not in the dictionary, add it along with priority
        # else let user know task already exists
        if new_task not in dict_todo:
            new_priority = input("Input the priority: ")
            dict_todo[new_task] = new_priority
            print(new_task, " has been added to your chore list.")
        else:
            print("\n You've already added that chore! ")

    # step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        delete_task = input("What task would you like to remove? ")
        # if the user defined task is in the dictionary, delete it the task of choice
        # else let user know the task does not exist in dictionary
        if delete_task in dict_todo:
            del dict_todo[delete_task]
            print("You've deleted the task: ", delete_task)
        else:
            print("That task doesn't exist!")

    # step 6 - Save tasks to the "ToDo.txt" file
    elif(strChoice == '4'):
        print("Saving tasks to file...")
        #Preparint to write to a text file
        todo_file = open('C:\TIJERB\\UW_Python\Module05\\todo.txt', 'w')
        # for the key and values in the dictionary items
        # write the keys and values on one line, separated by a comma and create a new line
        for keys, values in dict_todo.items():
            todo_file.write(str(keys) + "," + str(values) + "\n")
        print("Done!")
        # must close the file afterwards
        todo_file.close()
    elif (strChoice == '5'):
        print("Great job!")
        break