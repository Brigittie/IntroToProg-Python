#--------------------------------#
#Title: ToDoScript.py
#Dev: Brigittie Tijerina
#Description: This program shows users what chores/priorities have been assigned items in a text file.
# When running the program, users are able to choose add, delete, and print out their new task list onto the text file.
#Change Log: 2019-02-11, Created File
#2019-02-18, Grouped program into logical functions via "Abstraction Method"
#--------------------------------#

class todo_task_class():
    """ This class contains methods for the Todo_Script_Abstraction Program """
    # Defines the method
    @staticmethod

    def menu_of_options():
        """This function displays a menu of options available to the user"""
        print(
            """
            Task Keeper: Menu 
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
        user_choice = str(input("Which option do you choose? [1 to 5] - \n"))
        return user_choice

    def show_current_items():
        """This function shows the user a view of tasks with priorities from their task file"""
        print("Printing task list and priority value: \n")
        for keys in dict_todo_variable:
            value = dict_todo_variable.get(keys)
            print(keys, "-", value)

    def add_new_item():
        """This function allows users to add a new task/priority to their task file"""
        new_task = input("Input the new task: ")
        if new_task not in dict_todo_variable:
            new_priority = input("Input the priority: ")
            dict_todo_variable[new_task] = new_priority
            print(new_task, " has been added to your chore list.")
        else:
            print("\n You've already added that chore! ")
        return new_task

    def delete_item():
        """This functiion allows users to delete existing tasks from their task file"""
        delete_task = input("What task would you like to remove? ")
        if delete_task in dict_todo_variable:
            del dict_todo_variable[delete_task]
            print("You've deleted the task: ", delete_task)
        else:
            print("That task doesn't exist!")
        return delete_task

    def save_to_file():
        """This function allows users to save their tasks to their task file"""
        print("Saving tasks to file...")
        todo_file = open('C:\TIJERB\\UW_Python\Module05\\todo.txt', 'w')
        for keys, values in dict_todo_variable.items():
            todo_file.write(str(keys) + "," + str(values) + "\n")
        print("Done!")
        todo_file.close()

    def exit_program():
        """This function allows users to exit their program"""
        print("Exiting the program. Thank you!")
        exit()

    def read_from_file(file_name):
        """This function allows users to read from a task file of their choice"""
        todo_file = open(file_name, 'r')
        return todo_file

    def create_dictionary_from_file():
        """This function allows users to create a task/priority dictionary from their selected task file"""
        dict_todo = {}
        for line in todo_file_variable:
            chore_priority_split = line.split(",")
            chore = chore_priority_split[0]
            priority = chore_priority_split[1]
            remove_newline_char = len(priority) - 1
            priority = priority[0:remove_newline_char]
            dict_todo[chore] = priority
        return dict_todo

# -- presentation (I/0) code --
# Program
todo_file_variable = todo_task_class.read_from_file(file_name='C:\TIJERB\\UW_Python\Module06\\todo.txt')
dict_todo_variable = todo_task_class.create_dictionary_from_file()

while (True):
    strChoice = todo_task_class.menu_of_options()
    if (strChoice.strip() == '1'):
        todo_task_class.show_current_items()
    elif (strChoice.strip() == '2'):
        todo_task_class.add_new_item()
    elif (strChoice == '3'):
        todo_task_class.delete_item()
    elif (strChoice == '4'):
        todo_task_class.save_to_file()
    elif (strChoice == '5'):
        todo_task_class. exit_program()
