#--------------------------------#
#Title: Pickling.py
#Dev: Brigittie Tijerina
#Description: This program packs a dictionary into binary format and saves it into a text file.
# Then unpacks it by reading it from the saved file.
#Change Log: 2019-02-24, Created File
#--------------------------------#

#Importing the pickle module
import pickle

def packing():
    print("Pickling a Dictionary")

    #Creating a dictionary for pickling
    wardrobe = {}

    #Creating key/value pairs in the dictionary
    wardrobe["Tops"] = ("Sweater","T-shirt","Tanktop")
    wardrobe["Bottoms"] = ("Pants","Skirt","Leggings")
    wardrobe["Accessories"] = ("Hat","Belt","Jewelry")

    #Creating a binary file to store the objects for pickling
    #This line of code opens the file to store the pickled dictionary
    pickle_file = open("Pickle_Dictionary.dat", "wb")

    #Calling on the Pickling module, opening the file, and dumping the data from the dictionary into the file
    pickle.dump(wardrobe, pickle_file)

    pickle_file.close()


def unpacking():
    print("Unpickling a Dictionary")
    read_pickle_file = open("Pickle_Dictionary.dat", "rb")

    read_pickle_dictionary = pickle.load(read_pickle_file)

    read_pickle_file.close()

packing()
unpacking()





