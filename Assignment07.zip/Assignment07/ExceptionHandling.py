#--------------------------------#
#Title: ExceptionHandling.py
#Dev: Brigittie Tijerina
#Description: This program catches errors and displays them to a user should the user
# attempt to open a file that is different than the one specified.
#Change Log: 2019-02-24, Created File
#--------------------------------#


def read_from_file(file_name,mode):
    pickle_file = open(file_name,mode)
    return pickle_file


try:
    read_from_file = open("Pickle_Dictionary.dat","rb")
except IOError as e:
    print("Something went wrong! Check the file name and read/write mode", e)


